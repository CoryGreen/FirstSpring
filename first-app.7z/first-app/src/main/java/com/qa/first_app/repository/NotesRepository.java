package com.qa.first_app.repository;
import com.qa.first_app.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
public interface NotesRepository extends JpaRepository <Notes,Long>{

}
